package sistemaing;
import Modelos.ConexionBD;

public class SistemaIng {

    public static void main(String[] args) {
        
    }
    
}
